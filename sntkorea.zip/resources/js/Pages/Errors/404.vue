<template>
    <div class="m-error-page type01">
        <h3 class="title primary">404 Error</h3>
        <p class="body">존재하지 않는 페이지입니다.</p>
    </div>
</template>
<script>
export default {}
</script>

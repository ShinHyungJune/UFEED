<template>
    <div class="m-error-page type01">
        <h3 class="title primary">403 Error</h3>
        <p class="body">권한이 없습니다.</p>
    </div>
</template>
<script>
export default {}
</script>

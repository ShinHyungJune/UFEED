<template>
    <div class="subContent">

    </div>
</template>
<script>
import {Link} from "@inertiajs/inertia-vue";

export default {
    components: {Link},
    data(){
        return {

        }
    },

    methods: {

    }
}
</script>

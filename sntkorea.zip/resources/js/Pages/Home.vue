<template>
  <div>
    home
  </div>
</template>
<script>
export default {

}
</script>

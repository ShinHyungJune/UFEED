<template>
    <div>
        <slot />
    </div>
</template>
<script>
import Flash from "../Components/Flash";
export default {
    components: {Flash}
}
</script>

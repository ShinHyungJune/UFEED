<template>
    <div class="m-empty type01">
        데이터가 없습니다.
    </div>
</template>
<style>
.m-empty.type01 {
    padding:60px 0; margin:20px 0;
    border-top:1px solid #e1e1e1; border-bottom:1px solid #e1e1e1;
    font-size:18px; color:#999; text-align: center;
}
</style>
<script>

export default {
    data(){
        return {
            active: false
        }
    },

    methods: {

    },

    computed: {

    },

    mounted() {

    }
}
</script>

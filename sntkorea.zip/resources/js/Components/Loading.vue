<template>
    <div class="loading-container">
        <div class="loading"></div>
        <div id="loading-text">처리중...</div>
    </div>
</template>
<script>

export default {
    components: {},

    data(){
        return {

        }
    },

    methods: {

    },

    mounted() {

    },

    watch: {

    }
}
</script>

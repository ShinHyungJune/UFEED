<template>
    <div class="m-quick type01">
        <div class="circle active">
            <h2 onclick="circle();">+<br>QUICK<br>MENU</h2>
            <ul>
                <li><a href="/facilities"><b>시설소개</b></a></li>
                <li><a href="/news/guides"><b>시설이용안내</b></a></li>
                <li><a href="/events/schedules"><b>대회일정</b></a></li>
                <li><a href="/news/boards"><b>보도자료</b></a></li>
                <li><a href="/intro/greeting"><b>재단소개</b></a></li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {

}
</script>

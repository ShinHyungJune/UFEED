<?php

return [
    "key" => env("IMP_KEY", "4251073285356543"),
    "secret" => env("IMP_SECRET", "CDtk0qs0eWnn801LD4am50byRehYaK8S79Wauhbmymf6UJWzywENKnxHcjcD3dlSPTFY6mCFOKgakXUW"),
    "imp_code" => env("IMP_CODE", "imp16710040") // 가맹점 식별코드
];

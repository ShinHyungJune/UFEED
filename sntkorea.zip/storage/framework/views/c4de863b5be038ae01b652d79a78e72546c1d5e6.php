<footer class="footer">
    <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</footer>
<?php /**PATH D:\project\coworkerweb.com\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>
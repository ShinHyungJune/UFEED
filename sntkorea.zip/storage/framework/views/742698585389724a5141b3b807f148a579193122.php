<?php echo e($slot); ?>

<?php /**PATH D:\project\coworkerweb.com\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>